
import { Component } from '@angular/core';

@Component({
    template: `<h1>Photo Details</h1>
    `
})
export class PhotoDetailsComponent {
}