
import { Component } from '@angular/core';

@Component({
    selector: 'messages',
    template: `<h1>Messages</h1>
    `
})
export class MessagesComponent {
}